<template>
  <v-app>
    <AppHeader/>
    <AppNavbar/>
    <v-main>
      <router-view />
    </v-main>

    <AppFooter />
  </v-app>
</template>

<script setup>
  //
</script>
<style>
</style>