<template>
  <v-app-bar app>
    <v-toolbar-title>
      <router-link to="/" class="v-btn v-btn--text">
      사이트 제목
    </router-link>
    </v-toolbar-title>
    <!-- 여기에 추가 네비게이션 항목 -->
  </v-app-bar>
    
</template>

<script setup>
  
  
</script>

<style scoped lang="sass">

</style>
