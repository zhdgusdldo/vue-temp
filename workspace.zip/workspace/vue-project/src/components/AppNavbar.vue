<template>
  <v-app-bar app dense>
    <router-link to="/users" class="v-btn v-btn--text">
      사용자 목록
    </router-link>
  </v-app-bar>
</template>

<script setup>
// 네비게이션 바 컴포넌트의 스크립트 부분
</script>