<!-- src/components/UserList.vue -->
<template>
  <div>
    <v-data-table
      :items="store.users"
      @dblclick:row="openDetailModal"
    >
    </v-data-table>
    <v-dialog v-model="isModalOpen" persistent max-width="600px">
      <v-card>
        <v-card-title>
          사용자 상세 정보
        </v-card-title>
        <v-card-text>
          <p>ID: {{ selectedUser.id }}</p>
          <p>Name: {{ selectedUser.name }}</p>
          <p>Email: {{ selectedUser.email }}</p>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="isModalOpen = false">닫기</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
import { useUserStore } from '@/stores/userStore';

const store = useUserStore();
const isModalOpen = ref(false);
const selectedUser = ref({});

onMounted(() => {
  store.fetchUsers();
});


function openDetailModal(event, row) {
  console.log(row.item)
  selectedUser.value = row.item;
  isModalOpen.value = true;
}

</script>
<style>

</style>