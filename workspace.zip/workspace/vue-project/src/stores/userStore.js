import { defineStore } from 'pinia';
import axios from 'axios';

export const useUserStore = defineStore('userStore', {
  state: () => ({
    users: [],
  }),
  actions: {
    async fetchUsers() {
      try {
        console.log('fetchUsers')
        //const response = await axios.get('https://localhost:3000/users');
        const response = {
          data : [
            {
              id : "1",
              name : "고객1",
              email : "email1@gmail.com"
            },
            {
              id : "2",
              name : "고객2",
              email : "email1@gmail.com"
            },
            {
              id : "3",
              name : "고객3",
              email : "email1@gmail.com"
            }
          ]
        }
        this.users = response.data;
      } catch (error) {
        console.error('fetchUsers error:', error);
      }
    },
  },
});