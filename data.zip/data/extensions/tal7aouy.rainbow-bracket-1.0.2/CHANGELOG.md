## v1.0.0

- initial release

## v1.0.1 (03/18/2022)

- v1.0.1

## v1.0.1 (03/18/2022)

- allow postcss syntax to be recognized as css
