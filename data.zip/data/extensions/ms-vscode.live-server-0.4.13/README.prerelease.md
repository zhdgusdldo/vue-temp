> **This is the pre-release edition of Live Preview for early feedback and testing. It works best with [VS Code Insiders](https://code.visualstudio.com/insiders).**
